var READTHEDOCS_DATA = {
    project: "smartthings",
    version: "latest",
    language: "en",
    programming_language: "py",
    subprojects: {},
    canonical_url: "http://docs.smartthings.com/en/latest/",
    theme: "sphinx_rtd_theme",
    builder: "sphinx",
    docroot: "/",
    source_suffix: ".rst",
    api_host: "https://readthedocs.org",
    commit: "afd3a2cf",
    ad_free: false,

    global_analytics_code: 'UA-17997319-1',
    user_analytics_code: 'UA-37953319-5'
};

